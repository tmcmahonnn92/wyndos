# Areas and frequency

An **area** is a group of customers cleaned together, usually a village, an estate or a group of streets. Areas are the heart of Wyndos: you book areas, not individual customers.

![Areas page](img/d-areas.png)

Each row shows:

- the area's colour
- how often it's cleaned
- when it's **next due**
- how many customers it has
- the value of one round

The icons on the right edit or delete the area.

## Add or edit an area

Press **+ Add Area**, or the pencil icon next to an existing area. Then set:

- **Area name**, for example "Cuckney".
- **Schedule type**. There are two kinds:
  - **Every N weeks**: set **Repeat every**, for example 4 weeks.
  - **Monthly (fixed day)**: pick a **day of the month**. Use 1–28 to avoid problems at the end of short months.
- **Next due date**: when this area should next be cleaned.

## Frequency belongs to the area

**Every customer in an area is cleaned at the area's frequency.** If you change an area from 4 weekly to 6 weekly, all its customers change with it.

If a few customers in the same village need a different frequency, make them **their own area**. For example:

- **Cuckney**: every 4 weeks
- **Cuckney (8 weekly)**: every 8 weeks

The import does this for you. A row whose frequency differs from its area goes into an area named "*area* (N weekly)".

## Moving customers between areas

Choose whichever way suits you:

- **On the Areas page:** open **Assign Customers**, choose a **Target Area**, then drag customers across or use the **Move** button.
- **On a customer's page:** press **Change Area**.
- **For many at once:** use **Customers → Bulk Edit** and change the **Area** column.

## Route order within an area

The order of houses on a day comes from the area's route order. To change it:

- **On the day screen:** drag jobs using **Reorder** (see [Working a day](03-working-a-day.md#changing-the-order)).
- **In the Scheduler:** drag jobs in the day pop-up.
