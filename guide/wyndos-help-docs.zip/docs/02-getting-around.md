# Getting around

## On a computer

The menu runs down the left-hand side. You only see the items your permissions allow. The owner sees all of them.

![Dashboard on a computer](img/d-dashboard.png)

1. **Today's Round**: the areas booked for today, with job count and value. Click it to open today's work.
2. **The menu**:
   - **Dashboard**: today at a glance.
   - **Schedule**: your list of days.
   - **Scheduler**: the planning diary. This is on computers only.
   - **Customers**, **Quotes**, **Areas** and **Payments**.
   - **Texts**: reminders and bulk messages.
   - **Accounting**: income, expenses and tax year.
   - **Settings**.
3. **Customers Owing**: who owes you money, with a shortcut to log a payment.

The dashboard also shows the round value, what's been earned, how many customers you have, the total owed, any **overdue areas**, and the next few booked days.

## On a phone

On a phone the menu moves to a bar along the bottom. The round **+** button in the middle opens **Quick add**.

![Dashboard on a phone](img/m-dashboard.png)

![Quick add menu](img/m-quick-add.png)

1. **New Customer**: add a customer.
2. **One-off Job**: book a single clean for a new or existing customer on any date.
3. **Book Quote**: book a visit to price up a new customer.

Under **More** are the pages that don't fit on the bottom bar: Scheduler, Quotes, Areas, Payments, Texts and so on.

## Install Wyndos on your phone

Wyndos works in the phone's web browser, but it's better installed on the home screen:

- **iPhone (Safari):** tap the **Share** button, then **Add to Home Screen**.
- **Android (Chrome):** tap the **⋮** menu, then **Install app** or **Add to Home screen**. Wyndos may also offer "Add Wyndos to home screen" itself.

Once installed, Wyndos opens full-screen and **keeps working with no signal**. If you tick jobs off offline, they're saved on the phone and sent as soon as signal returns. If something couldn't be saved, you'll see a warning: "Some offline changes couldn't be saved".

## Light and dark mode

The moon or sun button at the top (on a phone) or bottom-left (on a computer) switches between light and dark mode.

## Signing out

Use the **Sign out** button: at the bottom-left on a computer, or the arrow icon at the top on a phone.
