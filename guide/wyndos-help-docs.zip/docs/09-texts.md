# Texts

Wyndos texts customers for you:

- **Day reminders**: "we're coming tomorrow".
- **Cleaned, here's how to pay**: sent when an area is completed.
- **Payment reminders**: chasers for unpaid cleans.
- **Bulk texts**: to any group of customers you choose.

## Two ways to send

| | **From my phone (free)** | **Automatic (VoodooSMS)** |
|---|---|---|
| Cost | Free on your phone plan | Pay per text (VoodooSMS credits) |
| How | Each text opens in your phone's Messages app, ready to go. You tap Send, come back, and the next one opens | Sent for you in the background |
| Replies | Come straight to your phone | Go to VoodooSMS |
| Best for | Small rounds, and when you want replies | Large batches and fully automatic texts |

Set the default in **Settings → Messaging**. Every send screen also has a **From my phone / Automatic** switch, so you can choose each time.

> **Test mode.** While **Test mode** is on, automatic texts are **not sent**. They're written to the **Log** so you can check the wording. The yellow banner at the top of the screen reminds you. Turn test mode off in **Settings → Messaging** when you're ready.

## Day reminders

On the day screen, tap **Text reminders to this day's customers**. In the Scheduler, open a day and press **Text reminders**.

![Text reminders, top](img/m-text-reminders.png)

1. **Send from**: your phone or automatic.
2. **Start from a template**: choose any saved wording, such as Day reminder, Payment reminder or Cleaned / how to pay.
3. **The message**: edit it freely for this send. Tick **Use this wording next time too** to make it the new default.
4. **Placeholders**: tap one to insert customer details at the cursor. See [Placeholders](#placeholders).

Scroll down to see who will get it:

![Text reminders, bottom](img/m-text-reminders-2.png)

5. **Who's chosen**: everyone on the day with a mobile number is ticked, and "no mobile" customers are greyed out. Untick anyone you want to leave out, or use **All** or **None**. The grey box above shows a **preview** for the first customer and how many text credits it will use.
6. **Start sending**: from your phone, or **Send** / **Test send** for automatic.

## Sending from your phone, one by one

When you start sending from your phone, Wyndos works through the list with you:

![Phone send queue](img/m-phone-queue.png)

1. Progress: which text you're on, and how many have been opened.
2. **Open in Messages**: opens your Messages app with the number and text filled in. Press Send there, then come back to Wyndos. **The next customer opens by itself.** You can still edit the text before opening it.
3. **Skip**: leave this customer out.
4. **Back / Next**: move through the list without sending.

This works on both iPhone and Android. If you stop part-way, the rest wait for you. A green bar shows "N texts waiting to send from your phone" on the day screen and the Texts page. Press **Send now** to pick up where you left off.

## Bulk texts and chasing payments

The **Texts** page sends to any group of customers.

![Texts page, Send tab](img/d-texts-send.png)

1. **Who to**: pick a ready-made group:
   - **Everyone**.
   - **Unpaid cleans**: anyone with completed cleans they haven't paid for.
   - **Reminder due**: unpaid customers whose next payment reminder is due.
   - **Cleaning soon**: customers with a clean coming up.

   Narrow it further by area, tag or search. Each person shows what they owe and which reminder they're on.
2. **Choose all**: tick everyone in the list. You can also tick people one at a time.
3. **Start from a template**: for example **Payment reminder 1**.
4. **Send from**: your phone or automatic.
5. **Start sending** or **Send**.

## The text log

The **Log** tab lists every text: who it went to, which kind it was, the wording and when.

![Text log](img/d-texts-log.png)

1. Filter the log by kind of text.

Each text shows one of these statuses:

| Status | Meaning |
|---|---|
| **TEST – not sent** | Written in test mode. Nothing reached the customer |
| **Sent** | Delivered by VoodooSMS |
| **Failed** | VoodooSMS couldn't send it |
| **Waiting (phone)** | In your phone queue, not opened yet |
| **Opened on phone** | Opened in your Messages app |

## Automatic texts

**Settings → Messaging** controls the texts Wyndos sends by itself.

![Messaging settings](img/d-settings-texts.png)

1. **How texts are sent**: your phone or VoodooSMS, plus the **Test mode** switch. If you use your phone, automatic texts wait on the Texts page until you tap to send them.
2. **Windows cleaned, here's how to pay**: sent to each customer when you complete their area. It includes your bank details and uses the first line of their address as the payment reference. Direct debit customers are never sent it.
3. **Don't text people who paid on the day**: skips anyone marked **Done & Paid**.
4. **Payment reminders**: how many days after an unpaid clean to send the **1st** and **2nd** reminders (0 means off). Each reminder goes once for each unpaid clean. **Run reminders now** sends any that are due straight away. Once switched on, they run automatically every day.

## Templates

**Settings → Templates** holds the saved wording for every kind of text: day reminder, cleaned (how to pay), job complete, the three payment reminders, payment received, and so on.

![Templates](img/d-settings-templates.png)

1. Edit the wording in the box.
2. Tap a placeholder button to insert it at the cursor. **Bank details** is highlighted here.

Remember to press **Save Changes** at the top.

## Placeholders

Placeholders are swapped for each customer's details when the text is sent:

| Button | Placeholder | Becomes |
|---|---|---|
| First name | `{{customerFirstName}}` | Their first name. If the name looks like an address, it becomes "there" |
| Full name | `{{customerName}}` | Their full name |
| Address | `{{customerAddress}}` | Their address |
| Area | `{{areaName}}` | Their area |
| Date | `{{jobDate}}` | The clean's date, for example "Tue 27 Oct" |
| Price | `{{jobPrice}}` | The price of the clean |
| Owes | `{{amountDue}}` | Their total balance |
| Next due | `{{nextDueDate}}` | When they're next due |
| Bank details | `{{bankDetails}}` | From Settings → Business |
| Pay reference | `{{paymentReference}}` | The first line of their address |
| Business | `{{businessName}}` | Your business name |
| Business phone | `{{businessPhone}}` | Your phone number |

A text of up to 160 characters costs 1 credit on VoodooSMS. The preview shows how many credits each text will use.
