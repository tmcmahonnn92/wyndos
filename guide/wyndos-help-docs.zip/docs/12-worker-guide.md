# Worker guide

This chapter is for people working the round. You'll mostly use Wyndos on your phone. What you can see depends on what the owner has switched on for you, so your screens may have a few more or fewer buttons than these.

## Getting started

1. The owner sends you an **invite link** by email. Open it and choose your own password.
2. Go to **wyndos.io** and sign in with your email and that password.
3. Add Wyndos to your home screen so it opens like an app and works with no signal:
   - **iPhone (Safari):** tap **Share**, then **Add to Home Screen**.
   - **Android (Chrome):** tap **⋮**, then **Install app**.

Forgotten your password? Tap **Forgot password?** on the sign-in screen, or ask the owner to reset it for you.

## Your dashboard

![Worker dashboard](img/w-dashboard.png)

- **Today's Round**: your areas today, with the number of jobs. Tap it to start.
- **Done this week**: how many jobs you've finished.
- **Cash collected**: cash taken this week, which you hand over to the owner.
- **Upcoming days**: your next days.

## Your days

Tap **Schedule** on the bottom bar.

![Worker schedule](img/w-schedule.png)

Today's areas are at the top. Tap **Work today as one list** to see all your jobs together. The calendar underneath shows your upcoming days (switch between **Mo**nth, **W**ee**k** and **3D**ay).

## Working through your jobs

You only see the jobs given to you.

![Worker day](img/w-day.png)

1. **Start day**: tap when you begin.
2. **Add Job**: add a one-off job to your day.
3. **Done**: tap when a house is cleaned and they'll pay later.
4. **Done & Paid**: tap when they paid you there and then. Choose **Cash**, **Card** or **Bank**.

More things you can do:

- **By area / All jobs by street**: switch between keeping areas together and one list sorted by street.
- **Tap a customer's name** to:
  - change today's price, for example fronts only
  - add a note, such as "gate locked"
  - ring them
  - **Skip** them if you couldn't clean
- **Map pin**: opens the address in Google Maps.
- **Tags**:
  - **Usually: Cash**: how they normally pay.
  - **Owes £…**: they have money outstanding. If they pay it, leave the "Also pay the … owed" box ticked when you choose Done & Paid.
- **Notes** on the card, such as "watch overhead cables", come from the office. Read them before you start.
- **Tapped the wrong one?** Tap the job again and use **Undo**.

When you've finished, tap **Complete Day**. Anything you didn't get to is carried over, and the office can see it.

> **No signal?** Keep going. Your taps are saved on the phone and sent when the signal comes back. Don't close the app until they've gone through.

## Quick add

Tap the round **+** button at the bottom.

![Worker quick add](img/w-quick-add.png)

- **One-off Job**: book an extra clean, for someone new or existing, onto your day.
- **Book Quote**: someone asked for a price. Book a quote visit with their name, address and phone. See [Quotes](07-quotes.md) for how to mark it quoted, won or lost.
- **Payments**: if you have the All payments permission.

## Payments (if switched on)

Some workers can also see the **Payments** page, to log money received for any customer.

![Worker payments](img/w-payments.png)

## Printing your sheet

The printer button on the day screen prints your jobs only. The share button sends them as a PDF. See [Printing and sharing](10-printing-sharing.md).

## Worker FAQ

**I can't see a customer or a page the owner mentioned.**
Your permissions don't include it. Ask the owner to switch it on in Settings → Team.

**Prices don't show.**
The owner hasn't given you **See prices**. You can still tick jobs off.

**My day is empty.**
Jobs may be assigned to someone else. Check with the office, or look at the **Show jobs for** list.
