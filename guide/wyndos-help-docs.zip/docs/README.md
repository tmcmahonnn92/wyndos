# Wyndos help docs

Start with [Welcome](00-welcome.md).

1. [Welcome to Wyndos](00-welcome.md)
2. [Quick start](01-quick-start.md)
3. [Getting around](02-getting-around.md)
4. [Working a day](03-working-a-day.md)
5. [Planning with the Scheduler](04-scheduler.md)
6. [Areas and frequency](05-areas.md)
7. [Customers](06-customers.md)
8. [Quotes and one-off jobs](07-quotes.md)
9. [Payments and accounting](08-payments-accounting.md)
10. [Texts](09-texts.md)
11. [Printing and sharing the day](10-printing-sharing.md)
12. [Settings](11-settings.md)
13. [Worker guide](12-worker-guide.md)
14. [FAQ and troubleshooting](13-faq.md)
