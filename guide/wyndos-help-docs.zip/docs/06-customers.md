# Customers

## The customer list

![Customers list](img/d-customers.png)

The boxes at the top count visible customers, **overdue** customers (past their due date), **inactive** customers (hidden from scheduling) and the **outstanding debt**.

1. **Import**: bring in customers from a spreadsheet.
2. **Bulk Edit**: change many customers at once in a table.
3. **Tidy addresses**: check how addresses were split into house, street and town.
4. **+ Add Customer**: add one customer.

Use the search box to find someone by name or address. **Filters** narrows the list and **Show inactive** includes paused customers.

Each row shows the customer's area, when they're next due, their frequency, price and what they owe. The switch on the right makes a customer **active** or **inactive**. Inactive customers are kept on file but never booked.

## Add a customer

Press **+ Add Customer**. On a phone, use **+ → New Customer**.

![Add Customer form](img/d-add-customer.png)

1. **House no. / name** and **Street**, then **Town / village** and **Postcode**. Keep these separate: the day sheet sorts houses by street and house number.
2. **Shows as**: a preview of the full address that customers and workers will see.
3. **Area** and **Price**. The line underneath confirms the frequency, which comes from the area, and the next run, for example "Schedule every 4 weeks · next run 27 Oct".
4. **Usually pays by**: Cash, Bank transfer, Card and so on. This shows as a tag on the job card.

The rest of the form:

- **Phone**: a UK mobile, if you want to text them.
- **Email**.
- **Job type**: for example "Window Cleaning".
- **Advance notice**: tick this if they want warning before you come.
- **Notes**: shown on the job card, such as "watch overhead cables".

## The customer page

Click any customer to open their page.

![Customer page](img/d-customer-detail.png)

At the top are their price and **balance**. A red balance means they owe money. Below that are their next due date, area, address (with **Open in Maps**), status and tags.

The buttons:

- **Log Payment**: record money received.
- **One-off Job**: book an extra clean on any date.
- **Change Area**: move them to another area. Their frequency changes to the new area's.
- **Invoice**: produce a PDF invoice.
- **SMS**: text this one customer.

**Job History** lists every visit, with its date, price and status: pending, complete, skipped or moved. You can correct a past price with **Edit price**.

## Edit a customer

Press **Edit** at the top of their page.

![Edit Customer](img/d-customer-edit.png)

1. The address parts, the same as when adding.
2. **Clean every** is shown but can't be changed here, because it's set by the area. To change it, change the area's frequency or move the customer to an area with the frequency you want.

You can also set:

- **Leave a slip**: leave a note or slip after cleaning.
- **Paid by another customer**: for example a landlord who pays for several houses.
- **Active customer**: untick to pause them.
- GoCardless details, if you use it.

## Tidy addresses

Older or imported addresses are often one long line. **Customers → Tidy addresses** splits them into house, street and town, and lets you check the guesses.

![Tidy addresses](img/d-tidy-addresses.png)

1. Each row shows the customer, what the address **was**, and the split parts. Correct any box that's wrong. The yellow note at the top lists named houses with no street, which sort after the numbered houses in their town. Add a street if you know it.
2. Press **Save** when you're done.

## Bulk Edit

Bulk Edit shows every customer in a spreadsheet-style table so you can fix lots of details quickly.

![Bulk editor](img/d-bulk-edit.png)

1. The columns:
   - name, house no./name, street, town, postcode
   - area and price
   - **every** (read-only, from the area)
   - phone, email
   - usually pays, slip, advance notice

   Changed cells are highlighted. Filter by area or search at the top.
2. **Save changes** saves every edit in one go. The counter next to it shows how many rows you've changed.

## Import customers from a spreadsheet

**Customers → Import** takes an Excel (.xlsx, .xls) or .csv file. The column headings must be on the first row.

### Step 1: Upload

![Import step 1](img/d-import-upload.png)

1. **Template CSV** downloads a ready-made spreadsheet with every column Wyndos understands. Starting from it is the easiest way.

The columns Wyndos recognises:

| Column | Notes |
|---|---|
| Customer Name | Required |
| Area | Required. New areas can be created automatically |
| Price (£) | Required |
| Address (full line) | Or use the separate parts below |
| House name / number, Street, Town / village, Postcode | Better than a full line |
| Phone, Email, Notes, Job Name | |
| Next Due Date, Last Cleaned | Dates |
| Payment Method, Advance Notice, Leave a slip | Yes/No or text |
| Frequency (weeks) | A different frequency for the same area puts the customer in its own area |
| Tags | Separate with commas or semicolons |
| Active | Yes / No |

A file exported from **Settings → Data → Customers** imports straight back in.

### Step 2: Map the columns

![Import step 2](img/d-import-mapping.png)

1. For each Wyndos field, choose which column of your file it comes from. You can also:
   - **Concat**: join several columns together.
   - **Fixed**: use the same value for every row.
   - **Skip**: leave it out.

   A preview of the first row is shown under each field.

**Import options** at the top:

- **Create new areas automatically**: area names that don't exist yet are created.
- **Update existing customers**: customers with the same name, or the same name and address, are updated instead of added twice.
- **Start fresh**: deletes all existing customers first.

  > **Warning:** Start fresh can't be undone.

- **Import job history**: a second optional CSV of past cleans.

### Step 3: Preview and import

![Import step 3](img/d-import-preview.png)

Every row is checked before anything is saved. The **Issues** column flags problems such as a missing price or "not a mobile" (that number can't be texted). Fix them in your file, or go **Back to mapping**. When it says **ready**, run the import.
