# Quick start

This gets a new business from an empty account to a first worked day in about half an hour. Each step links to the full instructions.

## 1. Sign in

Go to **wyndos.io** and sign in with your email and password.

![Sign-in screen on a phone](img/m-signin.png)

1. Your email address.
2. Your password. If you've forgotten it, use **Forgot password?**.
3. **Sign in**.

> **Tip:** On a phone, add Wyndos to your home screen. It then opens like an app and keeps working when the signal drops. See [Install on your phone](02-getting-around.md#install-wyndos-on-your-phone).

## 2. Fill in your business details

Open **Settings → Business**. Enter your business name, phone number and address, and put your **bank / payment details** in the box near the bottom. These details appear on invoices and in the "windows cleaned, here's how to pay" text. Press **Save Changes**.

See [Settings → Business](11-settings.md#business).

## 3. Create your areas

Open **Areas** and press **+ Add Area** for each village or estate you clean. For each one, set:

- **how often** it's cleaned (every 4 weeks, for example)
- **when it's next due**

Every customer in an area follows that area's frequency. If some customers need a different frequency, give them their own area, for example "Cuckney (8 weekly)".

See [Areas and frequency](05-areas.md).

## 4. Add your customers

You can add customers in either of two ways:

- **Import a spreadsheet.** Go to **Customers → Import** and upload your existing list (Excel or CSV). This is best if you have more than a handful. See [Importing customers](06-customers.md#import-customers-from-a-spreadsheet).
- **Add them one by one.** Go to **Customers → + Add Customer**. See [Adding a customer](06-customers.md#add-a-customer).

After importing, open **Customers → Tidy addresses** and check that the house, street and town were split correctly. The street order on your day sheets depends on it.

## 5. Put the areas in the diary

Open the **Scheduler** on a computer and drag each area onto the day you'll clean it. After that, Wyndos books each area's next visit for you whenever you complete a day.

See [Planning with the Scheduler](04-scheduler.md).

## 6. Invite your team (optional)

In **Settings → Team**, type a worker's email, choose **Worker**, **Senior worker** or **Office / admin**, and press **Send invite**. They set their own password. You decide exactly what each person can see.

See [Team and permissions](11-settings.md#team-and-permissions).

## 7. Choose how texts are sent

In **Settings → Messaging**, choose how texts go out:

- **From my phone (free)**: each text opens in your phone's Messages app ready to send.
- **Automatic (VoodooSMS)**: texts are sent for you.

While you're getting started, leave **Test mode** on. Texts are then only written to the log and nothing reaches customers.

See [Texts](09-texts.md).

## 8. Work your first day

On your phone, open **Schedule** and tap **Work today as one list**.

1. Press **Start day**.
2. Tick each house off with **Done** or **Done & Paid** as you go.
3. When you're finished, press **Complete Day**. Anything you didn't get to is carried over.

See [Working a day](03-working-a-day.md).

**That's it.** From now on, completing an area books its next visit automatically. Your daily routine is: open today, work the list, complete the day.
