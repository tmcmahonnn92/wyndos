# Planning with the Scheduler

The Scheduler is the diary where you decide which area is cleaned on which day. It's built for a computer or tablet, so it doesn't appear on the phone's bottom bar. It needs the **Plan the diary** permission.

![Scheduler, week view](img/d-scheduler.png)

1. **Areas**: every area, with a colour showing how due it is. Drag an area onto a day to book it. The buttons along this bar:
   - **+ Area**: create a new area.
   - **One-off**: book a single job.
   - **Holidays**: block out days you're away. Booked work that lands on a holiday is flagged.
   - **Clear**: removes all future booked days. You'll be asked to confirm first.
2. **Week / Month**: change the view. Use the arrows to move between weeks or months.
3. **A booked day**: one area on one date, with its job count and value. Drag it to another date to move it, or click it to open the day (see below).
4. **Scheduler To-Do**: quick checks while you plan:
   - **Areas overdue**: press **Open** to jump to the area.
   - **Holiday conflicts**.
   - **Customers owing**.

The key at the bottom explains the colours: early/on time, 1–6 days overdue, 7–13 days overdue, and 14 or more days overdue.

## How booking works

- Drag an area onto a date to book its customers who are due.
- After you complete an area, its **next visit is booked automatically** using the area's frequency, counted from the day it was actually done. You mostly use the Scheduler to check and adjust, not to book everything by hand.
- To move a booked day, drag it to another date. You can also use **Rained off** on the day itself (see [Working a day](03-working-a-day.md#rained-off-move-the-day)).

## The day pop-up

Click a booked day to manage it without leaving the diary.

![Day pop-up in the Scheduler](img/d-scheduler-day.png)

1. **Who is doing this day**: give the whole day to one person.
2. **Assign jobs**: split the jobs between people. **Print / share for** chooses whose jobs go on the printout or PDF.
3. **Text reminders**: text everyone on this day. See [Day reminders](09-texts.md#day-reminders).
4. **View full day**: open the full day screen.

The pop-up also lets you:

- change a price or note for **this day only**, without changing the customer's regular price
- drag jobs into your route order
- mark jobs paid

> **Tip:** On a phone, use **Schedule** instead. You can do the same assigning and texting from the day screen itself.
