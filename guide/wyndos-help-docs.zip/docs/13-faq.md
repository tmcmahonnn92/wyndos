# FAQ and troubleshooting

## Schedule and areas

**How do I change how often a customer is cleaned?**
Frequency belongs to the area. Either change the area's frequency, which changes everyone in it, or move the customer to an area with the frequency you want, for example "Cuckney (8 weekly)". Create that area first if it doesn't exist.

**An area wasn't booked after I completed it.**
The next visit is booked when the area is **completed**. Check the day was completed, and not just had every job ticked. Look in the Scheduler under **Areas overdue**.

**I clicked a day on the Scheduler and want the full list.**
Press **View full day** in the pop-up.

**How do I move one customer to a different day this time only?**
Skip them on the day (they move to their next normal visit), or book a **One-off Job** for them on the day you want.

## On the round

**I ticked the wrong job.**
Tap the job again and press **Undo**.

**No signal.**
Carry on. Taps are saved on the phone and sent when you're back online. If something couldn't be saved, you'll see a warning.

**The price was different today.**
Tap the customer's name and change the **Price** before marking the job done. This changes today's visit only. To change their regular price, edit the customer.

**The list order is wrong.**
In **By area** view, use **Reorder** and drag the jobs. For a street-by-street order, switch to **All jobs by street**. It relies on tidy addresses, so check **Customers → Tidy addresses**.

## Texts

**Nobody received my texts.**
Check the yellow banner. If **Test mode** is on, texts only go to the log. Turn it off in **Settings → Messaging**. Also check that the customer's number is a UK mobile; landlines are marked "no mobile".

**Sending from my phone stopped after one text.**
After pressing Send in Messages, come back to Wyndos (swipe back or switch apps). The next customer opens by itself. If you left part-way, the green **"texts waiting"** bar lets you carry on.

**Where do replies go?**
With **From my phone**, replies come to your own phone. With VoodooSMS, they go to your VoodooSMS account.

**How much do texts cost?**
Texts from your phone cost nothing extra on most plans. On VoodooSMS, each text of up to 160 characters uses 1 credit. Longer texts use more, and the preview shows how many.

## Team

**A worker can see Accounting or Payments and shouldn't.**
Open **Settings → Team**, press the pencil icon next to them, and untick **All payments** and **Accounting**. **Their days** alone still lets them take payment at the door.

**A worker is locked out.**
Press the key icon next to them in **Settings → Team** to set a new password.

**A worker can't book a quote.**
They need the **Their days** permission. The quote goes on their own day.

## Data

**Can I get my data out?**
Yes. Go to **Settings → Data → Export**. The customers file can be imported back in at any time.

**I want to start again with the same customers.**
Go to **Settings → Data → Clear the schedule and all history**. Export first.
