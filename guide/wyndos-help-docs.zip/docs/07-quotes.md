# Quotes and one-off jobs

## Book a quote visit

When someone asks for a price, book a **quote visit**. It appears on that day's list like any other job, so whoever is nearby can call in and price it up.

On a phone, tap **+ → Book Quote**. On a computer, use **Quotes → + Book quote**.

![Book a quote visit](img/m-book-quote.png)

1. Choose what you're booking:
   - **Existing Customer**: an extra job for someone already on your books.
   - **New Customer**: a one-off job for someone new.
   - **Quote**: a visit to price up a new customer. This is the purple option in the picture.

For a quote, fill in:

- the **date** of the visit
- their **name**, **address**, **phone** and **email**
- the **area**, if you know it
- a **rough price**, if you have one
- any **notes**

Press **Book quote visit**. The person is saved with their details, but they won't be cleaned or repeated until you mark them as a live customer.

## On the day: mark quoted, won or lost

A quote visit shows on the day list with purple buttons:

1. **Mark quoted**: enter the **price quoted** and **how often**, plus a note such as "wants a callback Friday". Press **Save quote**.
2. **Mark live customer**: they said yes. Choose their **area**, confirm the price and how they'll usually pay, and press **Make live customer**. They join that area's runs from now on.
3. **Lost**: they said no. The quote is kept for your records.

## The Quotes page

![Quotes page](img/d-quotes.png)

The Quotes page follows every quote through four tabs:

- **To visit**: quote visits booked but not done yet.
- **Quoted**: priced, waiting for an answer. These are the ones to chase.
- **Won**: turned into live customers.
- **Lost**.

## One-off jobs

A **one-off job** is a single clean that doesn't repeat, such as a gutter clear, a conservatory roof or an end-of-tenancy clean. Book one from:

- **+ → One-off Job** on a phone
- **One-off** on the Schedule page or in the Scheduler
- **One-off Job** on a customer's page
- **Add Job** on the day screen

You can book it for an existing customer or a new one. It appears on the chosen date like any other job.

> **Workers** with the "Their days" permission can book quotes and one-off jobs too. The job goes on their own day.
