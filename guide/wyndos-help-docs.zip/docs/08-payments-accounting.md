# Payments and accounting

## How money is tracked

A customer starts to owe money when a job is marked **Done**. There are several ways to settle it:

- **Done & Paid** on the day, choosing Cash, Card or Bank.
- **Log Payment** on the Payments page or on the customer's page.
- **GoCardless** direct debits, matched automatically by **Sync GoCardless**.

When they pay, the money is set against their oldest unpaid cleans first.

## Payments page

![Payments page](img/d-payments.png)

- **Customers Owing** lists everyone with a balance. The coloured buttons filter it by area.
- Each customer has three buttons:
  - **Log Payment**: record money received.
  - **Invoice**: produce a PDF.
  - **Remind**: send a payment reminder.
- Tick several customers to deal with them together.
- **+ Log Payment** at the top records a payment for anyone.
- **Payment History**, further down, lists every payment received with the method and date.

> **Tip:** The easiest way to chase lots of people at once is **Texts → Unpaid cleans**. See [Bulk texts](09-texts.md#bulk-texts-and-chasing-payments). Wyndos can also send payment reminders automatically after a set number of days.

Only people with the **All payments** permission see this page. A worker who takes payment at the door only needs **Their days**.

## Accounting

The Accounting page shows your profit for each UK tax year (6 April to 5 April). It needs the **Accounting** permission.

![Accounting page](img/d-accounting.png)

- **Tax year and date range** (top): choose the tax year, or set your own dates and press **Apply range**.
- **Income, Expenses, Net**: totals for the chosen period. Income includes customer payments, anything you add by hand, and recurring income.
- **VAT on income / VAT on expenses**: shown if you're VAT registered.
- **Monthly breakdown**: income, expenses and net for each month.
- **Quick add**: record an **Expense** or **Other income**. Enter:
  - category
  - date
  - supplier
  - amount
  - VAT treatment
  - notes

  Expenses can **repeat** every so many days, weeks or months, for insurance, phone contract, van finance and so on.
- **Export summary CSV / Export expenses CSV**: send the figures to your accountant.
