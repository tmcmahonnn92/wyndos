# Welcome to Wyndos

Wyndos runs a window-cleaning round from one place. It holds your customers and the areas they belong to, plans which day each area is cleaned, and gives you and your team a simple list to work through on the phone. It also records who has paid and sends the reminder texts.

## Who this guide is for

| If you are… | Start here |
|---|---|
| The **owner** setting Wyndos up for the first time | [Quick start](01-quick-start.md) |
| The owner or office, **day to day** | [Getting around](02-getting-around.md), then the chapters you need |
| A **worker** on the round | [Worker guide](12-worker-guide.md). It stands on its own, so you can send just that chapter to new starters |
| Anyone stuck | [FAQ and troubleshooting](13-faq.md) |

## How the screenshots work

Most screenshots have **red numbered boxes**. Each number is explained in the list under the picture.

- Pictures with a dark menu down the left side are from a **computer**.
- Tall narrow pictures are from a **phone**.

The screens are the same on both. The phone just stacks things vertically and puts the menu along the bottom.

> **Tip:** Boxes like this one hold tips and warnings.

## Five words worth knowing

- **Area**: a group of customers you clean together, such as a village or an estate. Each area has its own **frequency**, for example every 4 weeks. A customer's frequency always comes from their area.
- **Day**: one area booked on one date. A date can have several days on it, such as Cuckney and Edwinstowe both on Tuesday.
- **Job**: one customer's clean on a day.
- **Done / Done & Paid**: how a job is ticked off. Use Done when they'll pay later and Done & Paid when they paid at the door.
- **Carry over**: jobs you didn't get to move on to another date when you finish the day.
