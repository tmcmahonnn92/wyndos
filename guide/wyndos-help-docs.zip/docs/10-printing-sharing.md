# Printing and sharing the day

Any day can be printed as a run sheet or shared as a PDF, for example over WhatsApp to a worker without the app.

## Print or share from the day screen

On the day screen, the two buttons next to **Start day** are:

- **Share** (three connected dots): makes a PDF of the day and opens your phone's **share menu**, so you can send it by WhatsApp, email, Messages and so on. On a computer, the PDF downloads instead.
- **Print** (printer): opens the run sheet ready to print.

The sheet follows whatever you're looking at:

- **By area** or **All jobs by street** order.
- **One area** or the whole day.

## Print for one worker

When a day is split between people, choose whose jobs to print. Open an area card, or the day pop-up in the Scheduler, and set **Print / share for**:

- **Everyone**, or
- one person, to get a sheet with only their jobs.

## The run sheet

![Run sheet](img/d-print.png)

1. **Share PDF**: the same PDF, shared from this page.
2. **Print**: sends the sheet to your printer.

For each house the sheet lists:

- the customer and address
- phone number
- price, and anything owed
- how they usually pay
- whether to leave a slip
- notes

There are **Done** and **Cash £** columns to fill in by hand. Use **Back** to return to the day.

> Prices are left off the sheet for anyone who doesn't have the **See prices** permission.
