# Working a day

This is the screen you'll use most. It's designed for a phone in one hand, but it works just as well on a computer.

## Open the day

Tap **Schedule** on the bottom bar. Today's areas are listed at the top.

![Schedule list](img/m-schedule.png)

- Tap **Work today as one list** to see every area booked today in one list. This is usually what you want.
- Tap a single area (for example **Cuckney → Open**) to see only that area.
- Use **One-off** to book a single extra job.

## The day screen

![Whole day, grouped by area](img/m-day-area.png)

The four boxes at the top show jobs **Done**, **Pending**, **Total** and money **Earned** so far. Below them:

1. **By area / All jobs by street**: how the list is arranged.
   - **By area** keeps each area together, in your saved route order.
   - **All jobs by street** mixes every area into one list, sorted by town, then street, then house number. This is handy when areas overlap.
2. **Show jobs for**: filter to one person's jobs, or show **Everyone**.
3. **One area / Whole day**: switch between the single area and every area booked on this date.
4. **Start day**: marks the day as under way. It then changes to **Complete Day**. Next to it are:
   - **Share**: sends the day as a PDF.
   - **Print**: opens the run sheet.
   - **Add Job**: adds a one-off job to the day.
5. **Text reminders**: text everyone on this day. See [Texts](09-texts.md#day-reminders).
6. **Rained off?**: move the whole day to another date. See [Rained off](#rained-off-move-the-day).

### Area cards

Each area booked today has a card showing jobs done out of total, value and status. Tap a card to open it.

![An opened area card](img/m-day-card.png)

1. The area. Tap it again to close the card.
2. **Open area only**: jump to just this area's page.
3. **Who is doing this day**: give the whole area to one person. The line underneath shows how the jobs are split, for example "Jake 2 · Tom 10".
4. **Assign jobs**: split the area's jobs between people (see below).
5. **Rained off**: move just this area to another date.

Under those buttons you can add **area notes**, such as "park by the church", which everyone working the area will see.

### Split jobs between workers

Tap **Assign jobs**. Tick the jobs you want to hand out, then choose who does them. Each job shows who has it now.

![Assign jobs panel](img/m-assign-jobs.png)

Workers only see the jobs given to them. Use **Show jobs for** at the top to check one person's list.

## Ticking off jobs

Every job has a card:

![A job card](img/m-job-card.png)

1. The customer, their job type and address. Tap the name to open the job's options (see below).
2. **Owes £…**: they have unpaid cleans from before. The coloured tags show how they **usually pay** (Cash, Bank transfer and so on) and who the job is assigned to.
3. **Map pin**: opens the address in Google Maps.
4. **Done**: the job is finished but not paid. It's added to what they owe.
5. **Done & Paid**: the job is finished and paid at the door.

### Done & Paid

When you tap **Done & Paid**, choose how they paid:

![Paid today by](img/m-done-paid.png)

1. **Cash**, **Card** or **Bank**.
2. If they owed money from earlier visits, this box is ticked to settle that too. Untick it if they're only paying for today.

### Changing the price, adding a note, or skipping

Tap the customer's name to open the job's options:

![Job options](img/m-job-sheet.png)

1. **Price**: change today's price, for example if you only did the fronts. This changes today's visit only.
2. **Note**: for example "gate locked, fronts only".
3. **Phone**: tap to ring the customer.
4. **Skip**: not cleaned this time. The job moves to their next normal visit.

**Mark Complete** is the same as **Done**, and **Done & Paid** works the same as on the card.

> **Made a mistake?** Tap a finished job to open it again and use **Undo**.

### Changing the order

In **By area** view, tap **Reorder** above the pending list, then drag jobs into your route order. Tap **Done reordering** when finished. The order is remembered for next time.

## Completing the day

When you're finished, press **Complete Day**. To finish just one area while the others carry on, open its card and press **Complete area**.

![Complete Day](img/m-day-started.png)

If any jobs are left, Wyndos asks what to do with them:

![Carry over unfinished jobs](img/m-complete-day.png)

1. How many jobs are unfinished. Ticked jobs are carried over. Untick any you want to skip until their next normal visit.
2. **New overdue day**: puts the carried-over jobs in a temporary "Overdue" group on the date you choose.
3. **Alongside an area**: adds them to another area's booked day.
4. **Carry over & complete**: finishes the day.

When an area is completed, Wyndos:

- books the area's **next visit** using its frequency, counted from the day it was actually done
- sends (or queues) the **"windows cleaned, here's how to pay"** text, if you've switched it on. See [Automatic texts](09-texts.md#automatic-texts).

## Rained off: move the day

Tap **Rained off? Move the whole day to another date**. You can also use **Rained off** on a single area card.

![Move to another date](img/m-rained-off.png)

1. Pick the new date.
2. Press **Move**.

Everything moves together. Each customer's next visit is still worked out from when the area is actually done, so nothing else needs changing.

## Texts waiting on your phone

If you send texts **from your phone**, a green bar shows how many are still waiting, for example "41 texts ready to send from your phone". Tap **Send** to carry on where you left off.
