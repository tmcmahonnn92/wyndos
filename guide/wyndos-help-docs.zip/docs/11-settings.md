# Settings

Settings is split into tabs along the top. **Business**, **Messaging**, **Templates**, **Broadcast** and **Tags** need the **Settings** permission. **Team** and **Data** are for the **owner only**. Remember to press **Save Changes** after editing.

## Business

Your business name, owner name, phone, email, address and logo. The logo is shown on invoices.

Further down are the other business settings:

![Business settings: bank details](img/d-settings-business.png)

1. **Bank / payment details**. These are printed at the bottom of every invoice and put into texts with the **Bank details** placeholder. Write them the way you'd want a customer to read them, for example: "Demo Window Cleaning, sort code 12-34-56, account 12345678".

The rest of this tab:

- **Invoice settings**:
  - **Invoice prefix**: for example "INV" gives INV-0001.
  - **Next invoice number**.
  - **VAT number**, if you have one.
- **GoCardless**: paste your GoCardless access token so direct-debit payments can be matched on the Payments page.

## Messaging and Templates

These tabs control how texts are sent, test mode, the automatic texts, and the saved wording. They're explained in full in [Texts](09-texts.md#automatic-texts).

**Broadcast** takes you to the **Texts** page for bulk messages.

## Tags

Create customer tags, such as "Commercial", "Key holder" or "Gutters". You can then tag customers on their page and filter by tag when texting.

## Team and permissions

![Team settings](img/d-settings-team.png)

### Invite someone

1. Type their email under **Invite a Worker**.
2. Choose a starting **role**:
   - **Worker**: sees and works their own days, and takes payment at the door.
   - **Senior worker**: also sees customers and payments, and can plan days.
   - **Office / admin**: everything except business settings.
3. Open **Custom permissions** to fine-tune the role, then press **Send invite**.

They get a link, create their own password, and join your business.

### Team members

Each person is listed with their role and permission tags. The numbered boxes in the picture:

1. **Edit permissions** (pencil icon): change what this person can do.
2. **Reset password** (key icon): set a new password for someone who's locked out. Type one, or leave it blank and Wyndos makes one up. Give it to them; they can change it later in **Settings → Security**.
3. **The permission switches**: tick or untick each one. Changes apply straight away.

**Worker pay report** shows each person's completed work for paying them.

### What each permission allows

| Permission | Lets them… |
|---|---|
| **Dashboard** | See the home screen with today's work |
| **Their days** | See and work the days or jobs given to them, take payment at the door, book quotes and one-off jobs on their own day |
| **See prices** | See prices and amounts owed on their jobs. Without it, prices are hidden, even on printouts |
| **Customers** | View, add and edit customers; see Quotes |
| **All payments** | See every customer payment, log or edit any payment, send invoices |
| **Texts** | Send day reminders and bulk texts |
| **Plan the diary** | Use the Scheduler: book, move and give out days |
| **Areas** | Create and change areas and their frequency |
| **Accounting** | See expenses, other income and business finances |
| **Settings** | Change business settings (not Team or Data) |

The owner always has everything. Giving someone **Their days** lets them take payment for their own jobs. It does **not** open the Payments or Accounting pages; those need **All payments** and **Accounting**.

### Security (your own password)

**Settings → Security** lets anyone change their own password: enter the current password, then the new one.

## Data

![Data settings](img/d-settings-data.png)

1. **Export**: downloads CSV files that open in Excel or Google Sheets:
   - **Customers**: everyone, with address parts, price, frequency, area and balance. This file can be imported straight back in.
   - **Jobs to do**: every booked visit not yet done.
   - **Job history**: every visit done, skipped or moved, with who did it and what was paid.
   - **Finances**: customer payments, expenses and other income.
2. **Clear the schedule and all history**: deletes every booked day and visit, every payment and every text log. **Keeps** your customers and areas (price, frequency, notes, order), so you can schedule from scratch. Expenses and other income are also kept. Type **CLEAR** to confirm.
3. **Clear everything**: deletes customers, areas, the schedule, history, payments, expenses, tags, holidays and texts. **Keeps** your business details, settings, templates and team. Type **DELETE EVERYTHING** to confirm.

> **Warning:** Neither clear can be undone. Export first.
